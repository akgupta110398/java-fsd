package com.app.todoapp.repository;

import com.app.todoapp.models.task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<task, Long> {

}
